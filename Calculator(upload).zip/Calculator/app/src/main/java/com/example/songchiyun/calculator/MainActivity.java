package com.example.songchiyun.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.lang.String;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText txt;
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    Button divide, result, multiply, add, minus, clear;
    boolean reset;  // useed to clear
    int cal;  // means which button was clickec before
    float preNum; //save number which is typed before
    boolean checked;   // protect double click on calculate button such as add, minus...


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        reset = true;
        checked = true;
        cal = 0;  // 0 is empty, get calculate button's id

        txt = (EditText)findViewById(R.id.result);
        btn0 = (Button)findViewById(R.id.num0);
        btn1 = (Button)findViewById(R.id.num1);
        btn2 = (Button)findViewById(R.id.num2);
        btn3 = (Button)findViewById(R.id.num3);
        btn4 = (Button)findViewById(R.id.num4);
        btn5 = (Button)findViewById(R.id.num5);
        btn6 = (Button)findViewById(R.id.num6);
        btn7 = (Button)findViewById(R.id.num7);
        btn8 = (Button)findViewById(R.id.num8);
        btn9 = (Button)findViewById(R.id.num9);

        divide = (Button)findViewById(R.id.divide);
        result = (Button)findViewById(R.id.finish);
        multiply = (Button)findViewById(R.id.multiply);
        add = (Button)findViewById(R.id.add);
        minus = (Button)findViewById(R.id.minus);
        clear = (Button)findViewById(R.id.clear);

        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        divide.setOnClickListener(this);
        result.setOnClickListener(this);
        multiply.setOnClickListener(this);
        add.setOnClickListener(this);;
        minus.setOnClickListener(this);
        clear.setOnClickListener(this);
        txt.setInputType(0);

    }

    public void onClick(View v){
        String temp = new String();
        temp ="";
        String storage;  //stoarge of value returning in calculate method

        if(v.getId() == btn0.getId()){
            checked = false;  // set calculate button is not inputted
            if(reset) { // if first input
                txt.setText("0");
                reset = false;
            }
            else{   //if it is not fist input
                if(!txt.getText().equals("0"))
                   txt.setText(txt.getText() + "0");
            }

        }
        if(v.getId() == btn1.getId()){
            checked = false;
            if(reset){
                txt.setText("1");
                reset = false;
            }
            else{
                zeroCheck(1); // check forehead input is zero
            }

        }
        if(v.getId() == btn2.getId()){
            checked = false;
            if(reset){

                txt.setText("2");
                reset = false;
            }
            else{
                zeroCheck(2);// check forehead input is zero
            }

        }
        if(v.getId() == btn3.getId()){
            checked = false;
            if(reset){

                txt.setText("3");
                reset = false;
            }
            else{
                zeroCheck(3);// check forehead input is zero
            }

        }
        if(v.getId() == btn4.getId()){
            checked = false;
            if(reset){

                txt.setText("4");
                reset = false;
            }
            else{
                zeroCheck(4);// check forehead input is zero
            }

        }
        if(v.getId() == btn5.getId()){
            checked = false;
            if(reset){

                txt.setText("5");
                reset = false;
            }
            else{
                zeroCheck(5);// check forehead input is zero
            }

        }
        if(v.getId() == btn6.getId()){
            checked = false;
            if(reset){

                txt.setText("6");
                reset = false;
                 }
            else{
                zeroCheck(6);// check forehead input is zero
            }

        }
        if(v.getId() == btn7.getId()){
            checked = false;
            if(reset){

                txt.setText("7");
                reset = false;
            }
            else{
                zeroCheck(7);// check forehead input is zero
            }

        }
        if(v.getId() == btn8.getId()){
            checked = false;
            if(reset){

                txt.setText("8");
                reset = false;
            }
            else{
                zeroCheck(8);// check forehead input is zero
            }

        }
        if(v.getId() == btn9.getId()){
            checked = false;
            if(reset){

                txt.setText("9");
                reset = false;
            }
            else{
                zeroCheck(9);// check forehead input is zero
            }

        }



        if(v.getId() == divide.getId()){
            if(!checked) {   // this method is only starting when checked is false

                if (cal == 0) { //has no inputted calculate button before
                    temp += txt.getText();
                    preNum = (float)Double.parseDouble(temp);
                    cal = v.getId();
                    reset = true;
                } else {
                    storage = Calculate(v.getId());
                    if (!storage.equals("error")) {  //check this calculate has error
                        txt.setText(String.valueOf(storage));
                        preNum = (float)Double.parseDouble(storage);
                        reset = true;
                    }
                }
                checked = true;
            }
        }

        if(v.getId() == multiply.getId()){
            if(!checked) {
                if (cal == 0) {
                    temp += txt.getText();
                    preNum = (float)Double.parseDouble(temp);
                    cal = v.getId();
                    reset = true;
                } else {
                    storage = Calculate(v.getId());
                    if (!storage.equals("error")) {
                        txt.setText(String.valueOf(storage));
                        preNum = (float)Double.parseDouble(storage);
                        reset = true;
                    }
                }
                checked = true;
            }
        }
        if(v.getId() == add.getId()){

            if(!checked) {
                if (cal == 0) {
                    temp += txt.getText();
                    preNum = (float)Double.parseDouble(temp);
                    cal = v.getId();
                    reset = true;
                } else {
                    storage = Calculate(v.getId());
                    if (!storage.equals("error")) {
                        txt.setText(String.valueOf(storage));
                        preNum = (float)Double.parseDouble(storage);
                        reset = true;
                    }
                }
                checked = true;
            }
        }
        if(v.getId() == minus.getId()){
            if(!checked) {
                if (cal == 0) {
                    temp += txt.getText();
                    preNum = (float)Double.parseDouble(temp);
                    cal = v.getId();
                    reset = true;
                } else {
                    storage = Calculate(v.getId());
                    if (!storage.equals("error")) {
                        txt.setText(String.valueOf(storage));
                        preNum = (float)Double.parseDouble(storage);
                        reset = true;
                    }
                }
                checked = true;
            }
        }
        if(v.getId() == result.getId()){

            if(!checked) {
                storage = Calculate(v.getId());
                if (!storage.equals("error")) {
                    txt.setText(String.valueOf(storage));
                    preNum = (float)Double.parseDouble(storage);
                    reset = true;
                    cal = 0;
                } else {
                    reset = true;
                    cal = 0;
                }
            }
        }
        if(v.getId() == clear.getId()){   //reset all attribute
            reset = true;
            preNum = 0;
            cal = 0;
            checked = true;
            txt.setText("0");
        }



    }
    private void zeroCheck(int num){    //check that first number is zero
        if(!txt.getText().equals("0"))
            txt.setText(txt.getText() + String.valueOf(num));
        else
            txt.setText(String.valueOf(num));
    }

    private boolean divideZeroCheck(int num){  //check this calculate is dividing by zero
        if(num == 0)
            return false;
        else
            return true;
    }

    private String Calculate(){   //it is only used  when user click result(=) button

        String temp = new String();
        float result = 0;
        temp = "";
        if(cal == add.getId()){    //already clicked cal button is add
            temp += txt.getText();
            result =  preNum + (float)Double.parseDouble(temp);  //editText set prenum + present txtMsg
        }
        if(cal == minus.getId()){  //already clicked cal button is add
            temp += txt.getText();
            result =  preNum - (float)Double.parseDouble(temp);
        }
        if(cal == multiply.getId()){
            temp += txt.getText();
            result =  preNum * (float)Double.parseDouble(temp);
        }

        if(cal == divide.getId()){
            temp += txt.getText();

            if(divideZeroCheck(Integer.parseInt(temp))){  //check divide by zero
                result =  preNum / (float)Double.parseDouble(temp);
            }
            else{
                 clear();
                return "error";  //divide by zero, then return error message
            }
        }
        return String.valueOf(result);
    }
    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {  //save state, string and number of cal, prenum, reset, check, txt
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("cal", cal);
        savedInstanceState.putDouble("prenum", preNum);
        savedInstanceState.putBoolean("reset", reset);
        savedInstanceState.putBoolean("check", checked);
        savedInstanceState.putString("txt", txt.getText().toString());
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState) { //reset state, string and number of cal, prenum, reset, check, txt
        super.onRestoreInstanceState(savedInstanceState);
        cal = savedInstanceState.getInt("cal");
        preNum = (float)savedInstanceState.getDouble("prenum");
        reset = savedInstanceState.getBoolean("reset");
        checked = savedInstanceState.getBoolean("check");
        txt.setText(savedInstanceState.getString("txt"));
    }

    private String Calculate(int id){  //this method called when cal button is clicked sequentially
 //logic is same as Calculate()
        String temp = new String();
        float result = 0;
        temp = "";
        if(cal == add.getId()){
            temp += txt.getText();
            result =  preNum + (float)Double.parseDouble(temp);
        }
        if(cal == minus.getId()){
            temp += txt.getText();
            result =  preNum - (float)Double.parseDouble(temp);
        }
        if(cal == divide.getId()){
            temp += txt.getText();
             if(divideZeroCheck(Integer.parseInt(temp))){
                result =  preNum / (float)Double.parseDouble(temp);
            }
            else{
                Toast.makeText(getApplicationContext(),"can't divid by zero !!",Toast.LENGTH_LONG).show();
                clear();
                return "error";
            }
        }
        if(cal == multiply.getId()){
            temp += txt.getText();
            result =  preNum * (float)Double.parseDouble(temp);
        }
        cal = id;
        return String.valueOf(result);
    }
    private void clear(){   //when the situation which is divide by zero occurs, then stop calculating and reset
        reset = true;
        cal = 0;
        preNum = 0;
        txt.setText("0");
    }
}
